public class accountant public class Accountant extends User{
    @Override
    String getPermissions() {
        return "";
    }{
}