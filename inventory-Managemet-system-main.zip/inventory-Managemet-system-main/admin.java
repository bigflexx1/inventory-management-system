public class Admin extends User {


    @Override
    String getPermissions() {
        return "";
    }


}