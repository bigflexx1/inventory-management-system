public class Cashier extends User{
    @Override
    String getPermissions() {
        return "";
    }


}