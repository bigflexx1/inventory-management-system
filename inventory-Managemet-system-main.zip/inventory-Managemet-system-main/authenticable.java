public interface Aunthenticable {
    boolean authenticate();
    String otp();
    String passkey();
}